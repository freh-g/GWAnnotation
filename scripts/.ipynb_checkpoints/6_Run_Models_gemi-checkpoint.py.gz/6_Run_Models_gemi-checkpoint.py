#!/usr/bin/env python3

import logging
import pickle as pkl
import random
import numpy as np
import pandas as pd
import cupy as cp
import matplotlib.pyplot as plt
import seaborn as sns

from xgboost import XGBClassifier
from hyperopt import fmin, tpe, hp, STATUS_OK, Trials
from sklearn.metrics import accuracy_score, roc_curve, auc

import hydra
from hydra.core.hydra_config import HydraConfig
from omegaconf import DictConfig

log = logging.getLogger(__name__)
np.random.seed(42)
random.seed(42)


# ---------------------------------------------------------
# Utility functions
# ---------------------------------------------------------

def get_X(df, X_cols):
    return df[X_cols]

def get_Y(df, condition):
    return df[f"{condition}_Target"]


def rm_intracondition_dupli(row, condition_cols):
    """Ensure each row has exactly one condition."""
    if row[condition_cols].sum() > 1:
        idxs = np.where(row[condition_cols].values == 1)[0]
        keep = np.random.choice(idxs)
        row[condition_cols] = 0
        row[condition_cols[keep]] = 1
    return row


# ---------------------------------------------------------
# Data loading and preprocessing
# ---------------------------------------------------------

def load_data(path):
    log.info(f"Loading dataset '{path}'")
    data = pd.read_csv(path)

    is_condition = lambda c: c.startswith("condition_") and not c.endswith("_Target")
    conditions = data.columns[data.columns.map(is_condition)]

    log.info(f"Found {len(conditions)} conditions")

    # Remove intra-condition duplicates
    data = data.apply(rm_intracondition_dupli, axis=1, args=[conditions])
    assert data[conditions].sum(axis=1).sum() == data.shape[0]

    # Split into per-condition datasets
    dfs = {cond: data[data[cond] == 1].copy() for cond in conditions}

    return dfs, conditions


def group_by_study(df):
    study_cols = [c for c in df.columns if c.startswith("study_id_")]
    groups = {col: df.index[df[col] == 1].tolist() for col in study_cols if df[col].sum() > 0}
    return groups


def remove_duplicates(study_groups, df):
    """Ensure each row belongs to exactly one study."""
    study_cols = list(study_groups.keys())
    summed = df[study_cols].sum(axis=1)
    dup_rows = summed[summed > 1].index

    for idx in dup_rows:
        cols = np.array(study_cols)[df.loc[idx, study_cols] == 1]
        keep = np.random.choice(cols)
        for col in cols:
            df.loc[idx, col] = 1 if col == keep else 0

    return df


# ---------------------------------------------------------
# Cross-validation split
# ---------------------------------------------------------

def study_leave_one_out(df, condition, study_groups):
    splits = []
    for test_group, test_idxs in study_groups.items():

        # Skip if too few positives
        if df.loc[test_idxs, f"{condition}_Target"].sum() < 50:
            continue

        val_splits = []
        for val_group, val_idxs in study_groups.items():
            if val_group == test_group:
                continue

            train_idxs = []
            for tr_group, tr_idxs in study_groups.items():
                if tr_group not in [test_group, val_group]:
                    train_idxs.extend(tr_idxs)

            val_splits.append((train_idxs, val_idxs))

        splits.append((test_idxs, val_splits))

    return splits


# ---------------------------------------------------------
# Training functions
# ---------------------------------------------------------

def train(dfs, dfs_splits, clf, condition, test_split, X_cols, auc_eval=False):
    df = dfs[condition]
    scores = []
    fprs, tprs, thrs = [], [], []

    for tr_idxs, val_idxs in dfs_splits[condition][test_split][1]:
        tr_X = cp.array(get_X(df.loc[tr_idxs], X_cols))
        tr_y = cp.array(get_Y(df.loc[tr_idxs], condition))

        clf.fit(tr_X, tr_y)

        val_X = cp.array(get_X(df.loc[val_idxs], X_cols))
        val_y = get_Y(df.loc[val_idxs], condition)

        if auc_eval:
            pred = clf.predict_proba(val_X)
            pred = pred.asnumpy() if not isinstance(pred, np.ndarray) else pred
            fpr, tpr, thr = roc_curve(val_y, pred[:, 1])
            scores.append(auc(fpr, tpr))
            fprs.append(fpr)
            tprs.append(tpr)
            thrs.append(thr)
        else:
            pred = clf.predict(val_X)
            scores.append(accuracy_score(val_y, pred))

    return (scores, fprs, tprs, thrs) if auc_eval else scores


def train_final(dfs, dfs_splits, clf, condition, model_idx, X_cols):
    df = dfs[condition]
    test_idxs = dfs_splits[condition][model_idx][0]

    tr_df = df.drop(index=test_idxs)
    ts_df = df.loc[test_idxs]

    tr_X = cp.array(get_X(tr_df, X_cols))
    tr_y = cp.array(get_Y(tr_df, condition))

    clf.fit(tr_X, tr_y)

    ts_X = cp.array(get_X(ts_df, X_cols))
    ts_y = get_Y(ts_df, condition)

    pred = clf.predict_proba(ts_X)
    pred = pred.asnumpy() if not isinstance(pred, np.ndarray) else pred

    fpr, tpr, thr = roc_curve(ts_y, pred[:, 1])
    score = auc(fpr, tpr)

    return score, fpr, tpr, thr


# ---------------------------------------------------------
# Hyperopt objective
# ---------------------------------------------------------

def make_objective(dfs, dfs_splits, X_cols):
    def objective(params):
        clf = XGBClassifier(
            gamma=params["gamma"],
            max_depth=int(params["max_depth"]),
            learning_rate=params["learning_rate"],
            subsample=params["subsample"],
            colsample_bytree=params["colsample_bytree"],
            reg_lambda=params["reg_lambda"],
            reg_alpha=params["reg_alpha"],
            scale_pos_weight=params["scale_pos_weight"],
            device=params["device"],
            random_state=42,
        )

        scores = train(
            dfs,
            dfs_splits,
            clf,
            params["condition"],
            params["test_split"],
            X_cols,
            auc_eval=False,
        )

        return {"loss": -np.mean(scores), "status": STATUS_OK}

    return objective


# ---------------------------------------------------------
# Main Hydra entry point
# ---------------------------------------------------------

@hydra.main(config_path="conf", config_name="xgboost.yaml", version_base="1.2")
def main(cfg: DictConfig):

    dfs, conditions = load_data(cfg["dataset"])

    # Build study groups
    study_groups = {c: group_by_study(dfs[c]) for c in conditions}

    # Remove duplicates
    for c in conditions:
        dfs[c] = remove_duplicates(study_groups[c], dfs[c])
        study_groups[c] = group_by_study(dfs[c])

    # Build splits
    dfs_splits = {c: study_leave_one_out(dfs[c], c, study_groups[c]) for c in conditions}

    # Build feature list
    sample_df = next(iter(dfs.values()))
    drop_cols = [c for c in sample_df.columns if c.startswith(("Ref_", "Alt_", "study_id_", "Chrom_", "condition_"))]
    drop_cols.append("Pos")
    X_cols = [c for c in sample_df.columns if c not in drop_cols]

    # Hyperopt search space
    space = {
        "gamma": hp.uniform("gamma", 0, 5),
        "max_depth": hp.uniformint("max_depth", 3, 20),
        "learning_rate": hp.uniform("learning_rate", 0.01, 0.3),
        "subsample": hp.uniform("subsample", 0.5, 1),
        "colsample_bytree": hp.uniform("colsample_bytree", 0.5, 1),
        "reg_lambda": hp.uniform("reg_lambda", 0, 1),
        "reg_alpha": hp.uniform("reg_alpha", 0, 1),
        "scale_pos_weight": hp.uniform("scale_pos_weight", 0, 5),
        "device": "cuda",
    }

    objective = make_objective(dfs, dfs_splits, X_cols)

    best_params = {}
    logs = {}

    for cond in conditions:
        best_params[cond] = []
        logs[cond] = []

        for i_model in range(len(dfs_splits[cond])):
            trials = Trials()
            space["condition"] = cond
            space["test_split"] = i_model

            best = fmin(
                fn=objective,
                space=space,
                algo=tpe.suggest,
                max_evals=10,
                trials=trials,
                rstate=np.random.default_rng(42),
            )

            best_params[cond].append(best)
            logs[cond].append(trials)

    with open("best_params.pkl", "wb") as f:
        pkl.dump(best_params, f)

    with open("trials_logs.pkl", "wb") as f:
        pkl.dump(logs, f)

    # Final training
    metrics = {}

    for cond in conditions:
        cond_metrics = {"scores": [], "fpr": [], "tpr": [], "thr": [], "models": []}

        for i_model, params in enumerate(best_params[cond]):
            clf = XGBClassifier(
                gamma=params["gamma"],
                max_depth=int(params["max_depth"]),
                learning_rate=params["learning_rate"],
                subsample=params["subsample"],
                colsample_bytree=params["colsample_bytree"],
                reg_lambda=params["reg_lambda"],
                reg_alpha=params["reg_alpha"],
                scale_pos_weight=params["scale_pos_weight"],
                device="cuda",
                random_state=42,
            )

            score, fpr, tpr, thr = train_final(dfs, dfs_splits, clf, cond, i_model, X_cols)

            cond_metrics["scores"].append(score)
            cond_metrics["fpr"].append(fpr)
            cond_metrics["tpr"].append(tpr)
            cond_metrics["thr"].append(thr)
            cond_metrics["models"].append(clf)

        metrics[cond] = cond_metrics

    with open("metrics.pkl", "wb") as f:
        pkl.dump(metrics, f)


if __name__ == "__main__":
    main()
