#!/usr/bin/env bash
set -euo pipefail

echo "Starting analysis pipeline"

echo "STEP 1 / 6  |  Downloading the studies"
# python 1_download_studies.py
echo "STEP 1 completed"

echo "STEP 2 / 6  |  parsing the studies"
# python 2_parse_studies.py
echo "STEP 2 completed"

echo "STEP 3 / 6  |  Lifting and preparing vcfs"
# python 3_lift_and_make_vcfs.py
echo "STEP 3 completed"

echo "STEP 4 / 6  |  Annotating the vcfs"
# python 4_annotate_parallel.py
echo "STEP 4 completed"

echo "STEP 5 / 6  |  Preprocessing vcfs"
# python 5_preprocessing.py
echo "STEP 5 completed"

echo "STEP 6 / 6  |  Running models"
./run_xgb.sh
echo "STEP 6 completed"

echo "Pipeline Completed succesfully"
