#!/usr/bin/env python3
"""
This script loads GWAS associations and annotate them using CADD features
"""

# =====================
# Imports
# =====================
import argparse
import pandas as pd
import pickle as pkl
import shutil
import os
from multiprocessing import Pool, cpu_count
from sklearn.utils import resample
import subprocess



def main():
    features = pd.read_csv('/home/francesco.gualdi/scratch/Projects/AI_PRS_CADD/CADD_chrs/Cols/CADD_chunk0000.tsv',sep='\t').columns.tolist()
    columns = ['rsid','beta','p_value','study_id','sample_size','Target'] + features
    
    vcf_folder_path = '/home/francesco.gualdi/scratch/Projects/AI_PRS_CADD/XGB_Pipeline/lifted_vcfs/'
    annotated_output_path = '/home/francesco.gualdi/scratch/Projects/AI_PRS_CADD/XGB_Pipeline/annotated_vcfs/'
    pipeline_dir = '/home/francesco.gualdi/scratch/scripts/merging_pipeline/'
    current_dir = os.getcwd()
    os.chdir(pipeline_dir)
    for file in os.listdir(vcf_folder_path):
        if 'check' not in file:
            subprocess.run(['bash', './annotate_vcf_CADD.sh', vcf_folder_path + file , annotated_output_path + file + '_chunk', 
                            annotated_output_path + file + '_chunk', annotated_output_path + file + '_chr', 
                            annotated_output_path + file + '_chr', annotated_output_path + file + '_annotated', '40' ])
    os.chdir(current_dir)



    
# ------- merge datasets in a single one for every EFO --------- # 
    for efofile in os.listdir(annotated_output_path):
        listofdf = []
        if 'annotated' in efofile:
            print(efofile)
            for chunk in os.listdir(os.path.join(annotated_output_path,efofile)):
                if 'check' not in chunk:
                    t = pd.read_csv(os.path.join(annotated_output_path,efofile,chunk),sep='\t',header=None)
                    t = t.iloc[:,4:]
                    t.columns = columns 
                    listofdf.append(t)
            final = pd.concat(listofdf,ignore_index=True)
            print(final.Target.value_counts())
            final.to_csv(os.path.join(annotated_output_path,efofile.split('.')[0]+'_annotated.tsv'),sep = '\t') 

# # ------- Remove the folders --------- # 

#     for item in os.listdir(annotated_output_path):
#         item_path = os.path.join(annotated_output_path, item)
#         if os.path.isdir(item_path):
#             shutil.rmtree(item_path)
            




# =====================
# Entry point
# =====================
if __name__ == "__main__":
    main()
