#!/usr/bin/env python3

import pickle
import sys
import hydra
import logging
from hydra.core.hydra_config import HydraConfig
from omegaconf import DictConfig
import numpy as np
import random
import pandas as pd
from xgboost import XGBClassifier
from hyperopt import fmin, tpe, hp, STATUS_OK, Trials
from sklearn.metrics import accuracy_score, roc_curve, auc
import pickle as pkl
import matplotlib.pyplot as plt
import cupy as cp
import seaborn as sns

log = logging.getLogger(__name__)
np.random.seed(42)


# def rm_intracondition_dupli(row: pd.Series, condition_cols: list):
#     if row[condition_cols].sum() > 1:
#         idxs = (row[condition_cols] == 1).to_numpy().nonzero()[0]
#         idx_condition_keep = random.sample(idxs.tolist(), 1)[0]
#         new_conditions = np.zeros(len(condition_cols))
#         new_conditions[idx_condition_keep] = 1
#         return 
#     return row

def get_X(df: pd.DataFrame, feature_cols: list):
    return df[feature_cols]

def get_Y(df: pd.DataFrame, condition: str):
    return df[(condition + '_Target')]
    
# train loop for nested cross validation
def train(dfs,dfs_splits,clf: XGBClassifier, condition: str, test_split:  X_cols ,nt, auc_eval: bool = False):
    df = dfs[condition]
    scores = []
    fpr_ls, tpr_ls, thresholds_ls = [], [], []
    for split in dfs_splits[condition][test_split][1]:
        tr_idxs, val_idxs = split
        tr_X, tr_y = get_X(df.loc[tr_idxs]), get_Y(df.loc[tr_idxs], condition)
        #load in gpu
        tr_X, tr_y = cp.array(tr_X), cp.array(tr_y)
        clf.fit(tr_X, tr_y)
        val_X, val_y = get_X(df.loc[val_i,X_colsdxs]), get_Y(df.loc[val_idxs], condition)
        val_X, val_y = cp.array(val_X), val_y
        if auc_eval:
            pred_y = clf.predict_proba(val_X)
            # put pred in cpu
            if type(pred_y) != np.ndarray:
                pred_y = pred_y.asnumpy()
            fpr, tpr, thresholds = roc_curve(val_y, pred_y[:,1])
            score = auc(fpr, tpr)
            fpr_ls.append(fpr)
            tpr_ls.append(tpr)
            thresholds_ls.append(thresholds)
        else:
            pred_y = clf.predict(val_X)
            score = accuracy_score(val_y, pred_y)
        scores.append(score)
    if auc_eval:
        return scores, fpr_ls, tpr_ls, thresholds_ls
    return scores



def study_leave_one_out(df: pd.DataFrame, condition: str, study_groups: dict):
    test_splits = []
    for k_test in study_groups:
        test_idxs = study_groups[k_test]
        # we exclude test sets that have less than 50 positives
        if df.loc[test_idxs, f'{condition}_Target'].sum() < 50:
            continue
        val_splits = []
        for k_val in study_groups:
            if k_val == k_test:
                continue
            val_idxs = study_groups[k_val]
            tr_idxs_list = []
            for k_tr in study_groups:
                if k_tr == k_test or k_tr == k_val:
                    continue
                tr_idxs = study_groups[k_tr]
                tr_idxs_list.extend(tr_idxs)
            split = (tr_idxs_list, val_idxs)
            val_splits.append(split)
        test_splits.append((test_idxs, val_splits))
    return test_splits

def rm_intracondition_dupli(row: pd.Series, condition_cols: list):
    if row[condition_cols].sum() > 1:
        idxs = np.where(row[condition_cols].values == 1)[0]
        idx_condition_keep = np.random.choice(idxs)

        # set all condition columns to 0
        row[condition_cols] = 0

        # set only one condition to 1
        row[condition_cols[idx_condition_keep]] = 1

    return row


def load_data(path: str) -> dict:
    """
    Loads the data and preprocess for training pipeline.
    """
    log.info(f"Loading dataset '{path}'")
    data = pd.read_csv(path)
    print([ a for a in data.columns.tolist() if 'study' in a])
    log.info(f"Loaded dataset of shape {data.shape}, memory usage {\
        data.memory_usage().sum()/1024**3:.2f}GB")
    is_condition_column = lambda c: str(c).startswith("condition_") and \
        not str(c).endswith("_Target")
    conditions = data.columns[data.columns.map(is_condition_column)]
    print(conditions)
    msg = f"Splitting dataset into {len(conditions)} conditions:"
    for condition in conditions:
        msg += f"\n\t- {condition}" 
    log.info(msg)
    # remove intra-conditions duplicates
    data = data.apply(rm_intracondition_dupli, axis=1, args=[conditions])
    assert data[conditions].sum(axis=1).sum() == data.shape[0]
    dfs = {}
    for condition in conditions:
        dfs[condition] = data[data[condition]==1]
    log.info(f"Split completed")
    return dfs
    

def group_by_study(df_condition: pd.DataFrame):
    study_cols = [col for col in df_condition.columns if col.startswith('study_id_')]
    study_groups = {}
    for col in study_cols:
        col_data = df_condition[col]
        if col_data.sum() == 0:
            continue
        study_groups[col] = col_data[col_data == 1].index
    return study_groups


def remove_duplicates(study_groups: dict, df_condition: pd.DataFrame):
    """ Performs an in place delete of the duplicates studies by choosing one randomly to keep 1, and the others to be set to 0 
    """
    study_cols = study_groups.keys()
    summed = df_condition[study_cols].sum(axis = 1)
    mask = summed > 1
    to_drop = summed[mask]
    # for every row, select the column names that have a 1, then select one randomly to keep 1 and the others set to 0
    for i in to_drop.index:
        # print(df_condition[study_cols].loc[i] == 1)
        # print(np.array(list(study_cols)))
        dupli_cols = np.array(list(study_cols))[df_condition[study_cols].loc[i] == 1]
        rnd_col = np.random.choice(dupli_cols, 1)[0]
        for col in dupli_cols:
            if col != rnd_col:
                df_condition.loc[i, col] = 0
    return df_condition


# hyperopt parameters
# def objective(dfs,params):
#     clf = XGBClassifier(
#         gamma = params['gamma'],
#         max_depth = params['max_depth'],
#         learning_rate = params['learning_rate'],
#         subsample = params['subsample'],
#         colsample_bytree = params['colsample_bytree'],
#         reg_lambda = params['reg_lambda'],
#         reg_alpha = params['reg_alpha'],
#         scale_pos_weight = params['scale_pos_weight'],
#         random_state = 42,
#         device = params['device']
#     )
#     scores = train(dfs,clf, params['condition'], params['test_split'])
#     score = np.mean(scores)
#     return {'loss': -score, 'status': STATUS_OK}


def make_objective(dfs, dfs_sp,X_colslits):
    def objective(params):
        clf = XGBClassifier(
            gamma=params['gamma'],
            max_depth=params['max_depth'],
            learning_rate=params['learning_rate'],
            subsample=params['subsample'],
            colsample_bytree=params['colsample_bytree'],
            reg_lambda=params['reg_lambda'],
            reg_alpha=params['reg_alpha'],
            scale_pos_weight=params['scale_pos_weight'],
            random_state=42,
            device=params['device']
        )

        condition = params['condition']
        test_split = params['test_split']

        scores = train(dfs, dfs_splits,clf, condition, test_split)
        return {'loss': -np.mean(scores), 'status': STATUS_OK}

    return objective




def tuning(dfs,dfsp,space,device = 'cuda'):
    space['device'] = device
    best_params = {}
    trials_logs = {}
    obj = make_objective(dfs,dfsp)
    for k in dfs:
        k_best_params = []
        k_trials_logs = []
        for i_model in range(len(dfsp[k])):
            trials = Trials()
            space['condition'] = k
            space['test_split'] = i_model
            best = fmin(
                fn = obj,
                space = space,
                algo = tpe.suggest,
                max_evals = 10,
                trials = trials,
                rstate = np.random.default_rng(42)
            )
            print(k, '-', i_model, ":", best)
            k_best_params.append(best)
            k_trials_logs.append(trials)
        best_params[k] = k_best_params
        trials_logs[k] = k_trials_logs
    return best_params,trials_logs

def train_final(dfs, clf, condition, i_model):
    df = dfs[condition]
    scores = []
    fpr_ls, tpr_ls, thresholds_ls = [], [], []
    ts_idxs = dfs_splits[condition][i_model][0]
    tr_X, tr_y = get_X(df.drop(index=ts_idxs)), get_Y(df.drop(index=ts_idxs), condition)
    ts_X, ts_y = get_X(df.loc[ts_idxs]), get_Y(df.loc[ts_idxs], condition)
    #load in gpu
    tr_X, tr_y = cp.array(tr_X), cp.array(tr_y)
    clf.fit(tr_X, tr_y)
    ts_X, ts_y = cp.array(ts_X), ts_y
    pred_y = clf.predict_proba(ts_X)
    # put pred in cpu
    if type(pred_y) != np.ndarray:
        pred_y = pred_y.asnumpy()
    fpr, tpr, thresholds = roc_curve(ts_y, pred_y[:,1])
    score = auc(fpr, tpr)
    return score, fpr, tpr, thresholds



@hydra.main(config_path="conf", config_name="xgboost.yaml", version_base="1.2")
def main(cfg: DictConfig):
    dfs = load_data(cfg["dataset"])
    print(dfs.values())
    dfs_study_groups = {}
    for k in dfs:
        dfs_study_groups[k] = group_by_study(dfs[k]) ### WHY THERE IS OG DATA INVOLVED?? ################################
    
    

    for k in dfs:
        dfs[k] = remove_duplicates(dfs_study_groups[k], dfs[k])     #### RE WE REMOVING DUPLICATED VARIANTS BETWEEEN STUDIES???
    # regroup and print final groups
    for k in dfs:
        dfs_study_groups[k] = group_by_study(dfs[k])
        lengths = []
        for j in dfs_study_groups[k]:
            print(j, len(dfs_study_groups[k][j]))
            lengths.append(len(dfs_study_groups[k][j]))
        print(k, 'length:', len(dfs[k]), 'groups sum:', np.sum(lengths))    
    # with open('./dfs.pkl', 'wb') as f:
    #     pickle.dump(dfs,f)

    # with open('./dfs_study_group.pkl', 'wb') as f:
    #     pickle.dump(dfs_study_groups,f)
    dfs_splits = {}
    for k in dfs:
        dfs_splits[k] = study_leave_one_out(dfs[k], k, dfs_study_groups[k])

    all_cols = dfs[k].columns
    to_drop = [c for c in all_cols if c.startswith("Ref_")]
    to_drop.extend([c for c in all_cols if c.startswith("Alt_")])
    to_drop.extend([c for c in all_cols if c.startswith("study_id_")])
    to_drop.extend([c for c in all_cols if c.startswith("Chrom_")])
    to_drop.extend([c for c in all_cols if c.startswith("condition_")])
    to_drop.append("Pos")
    X_cols = all_cols.drop(to_drop)
    X_cols = X_cols.to_list()
    pars = {
        'gamma': hp.uniform('gamma', 0, 5),
        'max_depth': hp.uniformint('max_depth', 3, 20),
        'learning_rate': hp.uniform('learning_rate', 0.01, 0.3),
        'subsample': hp.uniform('subsample', 0.5, 1),
        'colsample_bytree': hp.uniform('colsample_bytree', 0.5, 1),
        'reg_lambda': hp.uniform('reg_lambda', 0, 1),
        'reg_alpha': hp.uniform('reg_alpha', 0, 1),
        'scale_pos_weight': hp.uniform('scale_pos_weight', 0, 5)
        }   
    best_param,logs = tuning(dfs,dfs_splits,pars,device = 'cuda')
    with open('best_params.pkl', 'wb') as file:
        pkl.dump(best_params, file)
    with open('trials_logs.pkl', 'wb') as file:
        pkl.dump(logs, file)

    # retrain with best parameters on all train and validate on test
    metrics = {}
    models = {}
    for condition in best_params:
        models_params = best_params[condition]
        scores, fpr_ls, tpr_ls, thresholds_ls = [], [], [], []
        condition_models = []
        for i_model in range(len(best_params[condition])):
            params = models_params[i_model]
            clf = XGBClassifier(
                gamma = params['gamma'],
                max_depth = int(params['max_depth']),
                learning_rate = params['learning_rate'],
                subsample = params['subsample'],
                colsample_bytree = params['colsample_bytree'],
                reg_lambda = params['reg_lambda'],
                reg_alpha = params['reg_alpha'],
                scale_pos_weight = params['scale_pos_weight'],
                device = 'cuda',
                random_state = 42,
            )
            score, fpr, tpr, thresholds = train_final(dfs,clf, condition, i_model)
            scores.append(score)
            fpr_ls.append(fpr)
            tpr_ls.append(tpr)
            thresholds_ls.append(thresholds)
            condition_models.append(clf)
            print(condition, '-', i_model, 'auc:', score)
        metrics[condition] = {
            'scores': scores,
            'fpr_ls': fpr_ls,
            'tpr_ls': tpr_ls,
            'thresholds_ls': thresholds_ls,
            'models': condition_models
        }
    
    with open('metrics.pkl', 'wb') as file:
        pkl.dump(metrics, file)
        
if __name__ == "__main__":
    main()
